<!DOCTYPE html>
<html>
<head>
    <title>Customer Accounts</title>
</head>
<body>
    <nav>
        <a href="<?php echo e(url('/')); ?>">Home</a> |
        <a href="<?php echo e(url('/about')); ?>">About</a> |
        <a href="<?php echo e(url('/customers')); ?>">Customers</a> |
        <a href="<?php echo e(url('/users')); ?>">Users</a>
    </nav>
    <h1>Customer Accounts</h1>
    <ul>
        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($customer['name']); ?> - <?php echo e($customer['email']); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</body>
</html><?php /**PATH C:\Users\ncpablo\pos-laravel\resources\views/customers.blade.php ENDPATH**/ ?>