<!DOCTYPE html>
<html>
<head>
    <title>POS Home</title>
</head>
<body>
    <nav>
        <a href="<?php echo e(url('/')); ?>">Home</a> |
        <a href="<?php echo e(url('/about')); ?>">About</a> |
        <a href="<?php echo e(url('/customers')); ?>">Customers</a> |
        <a href="<?php echo e(url('/users')); ?>">Users</a>
    </nav>
    <h1>Home Page</h1>
    <p>Welcome to the Laravel POS system.</p>
</body>
</html><?php /**PATH C:\Users\ncpablo\pos-laravel\resources\views/home.blade.php ENDPATH**/ ?>