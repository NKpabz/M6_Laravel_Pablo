<!DOCTYPE html>
<html>
<head>
    <title>About POS</title>
</head>
<body>
    <nav>
        <a href="<?php echo e(url('/')); ?>">Home</a> |
        <a href="<?php echo e(url('/about')); ?>">About</a> |
        <a href="<?php echo e(url('/customers')); ?>">Customers</a> |
        <a href="<?php echo e(url('/users')); ?>">Users</a>
    </nav>
    <h1>About Page</h1>
    <p>This application is built for the Laravel POS foundations lab.</p>
</body>
</html><?php /**PATH C:\Users\ncpablo\TA6_M6\TA6_M6\resources\views/about.blade.php ENDPATH**/ ?>